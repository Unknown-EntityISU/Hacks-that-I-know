# Flappy Blook Cheats

### [Set Score](setScore.js)
Sets flappy blook score

### [Toggle Ghost](toggleGhost.js)
Lets you go through the pipes